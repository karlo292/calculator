#--------------------------------------#
#  Simple calculator made by karlo292  #
#--------------------------------------#

from functions import clear
from functions import formatNumber
clear()

#+
def add(n1,n2):
    return n1 + n2

#-
def subtract(n1,n2):
    return n1 - n2

#*
def multiply(n1,n2):
    return n1 * n2

#/
def divide(n1,n2):
    return n1 / n2

answer_n1 = False

while True:
    if answer_n1 == False:
        n1 = float(input("What is first number? \n"))
        clear()

    print("Choose operation:")
    print("+")
    print("-")
    print("*")
    print("/")
    operation = input("")
    clear()
    n2 = float(input("What is second number? \n"))
    clear()

    if operation == "+":
        answer = add(n1,n2)

    if operation == "-":
        answer = subtract(n1,n2)

    if operation == "*":
        answer = multiply(n1,n2)

    if operation == "/":
        answer = divide(n1,n2)

    print(f"{formatNumber(n1)} {operation} {formatNumber(n2)} = {formatNumber(answer)}")

    next_calculation = input("Would you like to continue calculating with answer? Y/N \n".lower())
    clear()
    if next_calculation == "n":
        answer_n1 = False
    elif next_calculation == "y":
        answer_n1 = True
        n1 = answer
        pass

    else:
        print("Invalid input")
        break