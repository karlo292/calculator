from os import system, name

#Clears screen
def clear():
    if name == 'nt':
        _ = system('cls')

    else:
        _ = system('clear')


#Formats float number ex. 5.0 = 5, 3.1 = 3.1
def formatNumber(num):
  if num % 1 == 0:
    return int(num)
  else:
    return num